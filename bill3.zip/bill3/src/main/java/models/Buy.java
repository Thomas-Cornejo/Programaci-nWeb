/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package models;

import java.util.List;
import models.Product;
/**
 *
 * @author LabSispc14
 */
public class Buy {

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the amount
     */
    public float getAmount() {
        return amount;
    }

    /**
     * @param amount the amount to set
     */
    public void setAmount(float amount) {
        this.amount = amount;
    }

    /**
     * @return the productos
     */
    public List<Product> getProductos() {
        return productos;
    }

    /**
     * @param productos the productos to set
     */
    public void setProductos(List<Product> productos) {
        this.productos = productos;
    }

    public Buy(int id, float amount, List<Product> productos) {
        this.id = id;
        this.amount = amount;
        this.productos = productos;
    }

    @Override
    public String toString() {
        return "Buy{" + "id=" + getId() + ", amount=" + getAmount() + ", productos=" + getProductos() + '}';
    }
    
    private int id;
    private float amount;
    private List<Product>productos;
}
