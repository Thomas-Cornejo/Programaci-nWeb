/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package models;

/**
 *
 * @author LabSispc14
 */
public class Customer {

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the email
     */
    public String getEmail() {
        return email;
    }

    /**
     * @param email the email to set
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * @return the addres
     */
    public String getAddres() {
        return addres;
    }

    /**
     * @param addres the addres to set
     */
    public void setAddres(String addres) {
        this.addres = addres;
    }

    /**
     * @return the numberPhone
     */
    public int getNumberPhone() {
        return numberPhone;
    }

    /**
     * @param numberPhone the numberPhone to set
     */
    public void setNumberPhone(int numberPhone) {
        this.numberPhone = numberPhone;
    }

    /**
     * @return the age
     */
    public int getAge() {
        return age;
    }

    /**
     * @param age the age to set
     */
    public void setAge(int age) {
        this.age = age;
    }

    public Customer(int id, String name, String email, String addres, int numberPhone, int age) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.addres = addres;
        this.numberPhone = numberPhone;
        this.age = age;
    }

    @Override
    public String toString() {
        return "customer{" + "id=" + id + ", name=" + name + ", email=" + email + ", addres=" + addres + ", numberPhone=" + numberPhone + ", age=" + age + '}';
    }
    
    private int id;
    private String name;
    private String email;
    private String addres;
    private int numberPhone;
    private int age;
}
