/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package models;

/**
 *
 * @author LabSispc14
 */
public class Supplier {

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the nameEnterprise
     */
    public String getNameEnterprise() {
        return nameEnterprise;
    }

    /**
     * @param nameEnterprise the nameEnterprise to set
     */
    public void setNameEnterprise(String nameEnterprise) {
        this.nameEnterprise = nameEnterprise;
    }

    /**
     * @return the numberPhone
     */
    public int getNumberPhone() {
        return numberPhone;
    }

    /**
     * @param numberPhone the numberPhone to set
     */
    public void setNumberPhone(int numberPhone) {
        this.numberPhone = numberPhone;
    }

    /**
     * @return the email
     */
    public String getEmail() {
        return email;
    }

    /**
     * @param email the email to set
     */
    public void setEmail(String email) {
        this.email = email;
    }

    public Supplier(int id, String name, String nameEnterprise, int numberPhone, String email) {
        this.id = id;
        this.name = name;
        this.nameEnterprise = nameEnterprise;
        this.numberPhone = numberPhone;
        this.email = email;
    }

    @Override
    public String toString() {
        return "supplier{" + "id=" + getId() + ", name=" + getName() + ", nameEnterprise=" + getNameEnterprise() + ", numberPhone=" + getNumberPhone() + ", email=" + getEmail() + '}';
    }

    private int id;
    private String name;
    private String nameEnterprise;
    private int numberPhone;
    private String email;
}
