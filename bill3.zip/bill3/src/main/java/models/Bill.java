/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package models;

/**
 *
 * @author LabSispc14
 */
import models.Employee;
import models.Customer;
import java.time.LocalDate;
import java.util.Date;

public class Bill {

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the dateTime
     */
    public LocalDate getDateTime() {
        return dateTime;
    }

    /**
     * @param dateTime the dateTime to set
     */
    public void setDateTime(LocalDate dateTime) {
        this.dateTime = dateTime;
    }

    /**
     * @return the total
     */
    public float getTotal() {
        return total;
    }

    /**
     * @param total the total to set
     */
    public void setTotal(float total) {
        this.total = total;
    }

    /**
     * @return the Employee
     */
    public Employee getEmployee() {
        return Employee;
    }

    /**
     * @param Employee the Employee to set
     */
    public void setEmployee(Employee Employee) {
        this.Employee = Employee;
    }

    /**
     * @return the Customer
     */
    public Customer getCustomer() {
        return Customer;
    }

    /**
     * @param Customer the Customer to set
     */
    public void setCustomer(Customer Customer) {
        this.Customer = Customer;
    }

    public Bill(int id, LocalDate dateTime, float total, Employee Employee, Customer Customer) {
        this.id = id;
        this.dateTime = dateTime;
        this.total = total;
        this.Employee = Employee;
        this.Customer = Customer;
    }

    @Override
    public String toString() {
        return "Bill{" + "id=" + getId() + ", dateTime=" + getDateTime() + ", total=" + getTotal() + ", Employee=" + getEmployee() + ", Customer=" + getCustomer() + '}';
    }
    
    private int id;
    private LocalDate dateTime;
    private float total;
    private Employee Employee;
    private Customer Customer;
    
}
