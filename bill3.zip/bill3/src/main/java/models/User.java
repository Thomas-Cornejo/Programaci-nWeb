/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package models;

/**
 *
 * @author LabSispc14
 */
import models.Employee;
public class User {

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the user
     */
    public String getUser() {
        return user;
    }

    /**
     * @param user the user to set
     */
    public void setUser(String user) {
        this.user = user;
    }

    /**
     * @return the password
     */
    public String getPassword() {
        return password;
    }

    /**
     * @param password the password to set
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * @return the Employee
     */
    public Employee getEmployee() {
        return employee;
    }

    /**
     * @param Employee the Employee to set
     */
    public void setEmployee(Employee Employee) {
        this.employee = Employee;
    }

    /**
     * @return the id
     */
    public User(int id, String user, String password, Employee employee) {
        this.id = id;
        this.user = user;
        this.password = password;
        this.employee = employee;
    }

    @Override
    public String toString() {
        return "user{" + "id=" + getId() + ", user=" + getUser() + ", password=" + getPassword() + ", Employee=" + getEmployee() + '}';
    }
    private int id;
    private String user;
    private String password;
    private Employee employee;
}
