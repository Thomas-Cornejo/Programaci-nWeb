/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controllers;

/**
 *
 * @author corne
 */
import models.Employee;
import java.util.ArrayList;
import java.util.List;
public class EmployeeControllers {
    private List<Employee>employeeList;
    
    public EmployeeControllers(){
        this.employeeList = new ArrayList<>();
    }
    public void crearEmployee(int id, String name, String role, String email, String number_phone, float salary){
        Employee employee = new Employee(id, name, role, email, number_phone, salary);
        employeeList.add(employee);
    }
    public Employee verEmployee(int id){
        for(Employee employee: employeeList){
            if(employee.getId() == id){
                return employee;
                
            }
        }
        return null;
    }
    public void actulizarEmployee(int id, String name, String role, String email, String number_phone, float salary){
        for (Employee employee : employeeList){
            if(employee.getId() == id){
                employee.setName(name);
                employee.setRole(role);
                employee.setEmail(email);
                employee.setNumberPhone(number_phone);
                employee.setSalary(salary);
            }
        }
    }
    public void eliminarEmployee(int id){
        employeeList.removeIf(employee -> employee.getId() == id);
    }
    public List<Employee> listarEmpleados(){
        return employeeList;
    }
}
