/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controllers;

import java.util.ArrayList;
import java.util.List;
import models.Buy;
import models.Product;

/**
 *
 * @author corne
 */
public class BuyControllers {
    private List<Buy> buyList;

    public BuyControllers() {
        this.buyList = new ArrayList<>();
    }
    public void crearBuy(int id, float amount, List<Product> productos) {
        Buy buy = new Buy(id, amount, productos);
        buyList.add(buy);
    }

    public Buy verBuys(int id) {
        for (Buy buy : buyList) {
            if (buy.getId() == id) {
                return buy;
            }
        }
        return null;
    }
    public void actualizarBuy(int id, float amount, List<Product> productos) {
        for (Buy buy : buyList) {
            if (buy.getId() == id) {
                buy.setAmount(amount);
                buy.setProductos(productos);
                break;
            }
        }
    }

    public void eliminarBuy(int id) {
        buyList.removeIf(buy -> buy.getId() == id);
    }

    public List<Buy> listarBuy() {
        return buyList;
    }
}
