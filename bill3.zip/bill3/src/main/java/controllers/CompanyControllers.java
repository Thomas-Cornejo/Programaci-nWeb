/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controllers;

import java.util.ArrayList;
import java.util.List;
import models.Company;

/**
 *
 * @author corne
 */
public class CompanyControllers {
   private List<Company> companyList;

    public CompanyControllers() {
        this.companyList = new ArrayList<>();
    } 
     public void crearCompanys(int id, String name, String address) {
        Company company = new Company(id, name, address);
        companyList.add(company);
    }

    public Company verCompany(int id) {
        for (Company company : companyList) {
            if (company.getId() == id) {
                return company;
            }
        }
        return null;
    }
    public void actualizarCompany(int id, String name, String address) {
        for (Company company : companyList) {
            if (company.getId() == id) {
                company.setName(name);
                company.setAddress(address);
                break;
            }
        }
    }
    public void elimnarCompany(int id) {
        companyList.removeIf(company -> company.getId() == id);
    }

    public List<Company> listarCompany() {
        return companyList;
    }
}
