/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controllers;

/**
 *
 * @author corne
 */
import java.util.ArrayList;
import java.util.List;
import models.Product;
import java.util.ArrayList;
import java.util.List;

public class ProductController {
    private List<Product> productList;

    public ProductController() {
        this.productList = new ArrayList<>();
    }

    public void crearProducto(int id, String name, String category, float price, String brand) {
        Product product = new Product(id, name, category, price, brand);
        productList.add(product);
    }

    public Product verProducto(int id) {
        for (Product product : productList) {
            if (product.getId() == id) {
                return product;
            }
        }
        return null; // Producto no encontrado
    }

    // Método para actualizar un producto
    public void actualizarProducto(int id, String name, String category, float price, String brand) {
        for (Product product : productList) {
            if (product.getId() == id) {
                product.setName(name);
                product.setCategory(category);
                product.setPrice(price);
                product.setBrand(brand);
                break; // Terminar después de actualizar
            }
        }
    }

    // Método para eliminar un producto por ID
    public void eliminarProducto(int id) {
        productList.removeIf(product -> product.getId() == id);
    }

    // Método para obtener todos los productos
    public List<Product> listarProductos() {
        return productList;
    }
}
 

