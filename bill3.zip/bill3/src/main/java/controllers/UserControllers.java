/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controllers;

import java.util.ArrayList;
import java.util.List;
import models.Employee;
import models.User;

/**
 *
 * @author corne
 */
public class UserControllers {
    private List<User> userList;

    public UserControllers() {
        this.userList = new ArrayList<>();
    }
    public void crearUser(int id, String user, String password, Employee employee) {
        User us = new User(id, user, password, employee);
        userList.add(us);
    }

    public User verUser(int id) {
        for (User user : userList) {
            if (user.getId() == id) {
                return user;
            }
        }
        return null;
    }
    public void actualizarUser(int id, String user, String password, Employee employee) {
        for (User us : userList) {
            if (us.getId() == id) {
                us.setUser(user);
                us.setPassword(password);
                us.setEmployee(employee);
                break;
            }
        }
    }
    public void elimnarUser(int id) {
        userList.removeIf(us -> us.getId() == id);
    }

    public List<User> listarUsers() {
        return userList;
    }
}
