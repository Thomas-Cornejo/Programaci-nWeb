/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controllers;

import java.util.ArrayList;
import java.util.List;
import models.Customer;

/**
 *
 * @author corne
 */
public class CustomerController {

    private List<Customer> customerList;

    public CustomerController() {
        this.customerList = new ArrayList<>();
    }

    public void crearCustomer(int id, String name, String email, String addres, int numberPhone, int age) {
        Customer customer = new Customer(id, name, email, addres, numberPhone, age);
        customerList.add(customer);
    }

    public Customer verCustomer(int id) {
        for (Customer customer : customerList) {
            if (customer.getId() == id) {
                return customer;
            }
        }
        return null;
    }

    public void actualizarProducto(int id, String name, String email, String addres, int numberPhone, int age) {
        for (Customer customer : customerList) {
            if (customer.getId() == id) {
                customer.setName(name);
                customer.setEmail(email);
                customer.setAddres(addres);
                customer.setNumberPhone(numberPhone);
                customer.setAge(age);
                break;
            }
        }
    }

    public void eliminarCustomer(int id) {
        customerList.removeIf(customer -> customer.getId() == id);
    }

    public List<Customer> listarCustomers() {
        return customerList;
    }

}
