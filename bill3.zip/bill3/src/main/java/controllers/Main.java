/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controllers;
import java.util.List;
import models.Product;

/**
 *
 * @author corne
 */
public class Main {
    public static void main(String[] args) {
        ProductController productManager = new ProductController();

        // Crear productos
        productManager.crearProducto(1, "Producto1", "Categoría1", 10000, "Marca1");
        productManager.crearProducto(2, "Producto2", "Categoría2", 12000, "Marca2");

        // Leer un producto por ID
        Product product = productManager.verProducto(1);
        if (product != null) {
            System.out.println("Producto encontrado: " + product.getName());
        } else {
            System.out.println("Producto no encontrado.");
        }

        // Actualizar un producto
        productManager.actualizarProducto(1, "Producto1 Actualizado", "Categoría1 Actualizada", 40000, "Marca1 Actualizada");

        // Eliminar un producto
        productManager.eliminarProducto(2);

        // Obtener todos los productos
        List<Product> allProducts = productManager.listarProductos();
        System.out.println("Lista de productos:");
        for (Product p : allProducts) {
            System.out.println(p.getId() + ": " + p.getName());
        }
    }
}

