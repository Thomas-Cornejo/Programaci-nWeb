/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controllers;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import models.Bill;
import models.Customer;
import models.Employee;

/**
 *
 * @author corne
 */
public class BillControllers {
    private List<Bill> billList;

    public BillControllers() {
        this.billList = new ArrayList<>();
    }
    public void crearBill(int id, LocalDate dateTime, float total, Employee Employee, Customer Customer) {
        Bill bill = new Bill(id, dateTime, total, Employee, Customer);
        billList.add(bill);
    }

    public Bill verBill(int id) {
        for (Bill bill : billList) {
            if (bill.getId() == id) {
                return bill;
            }
        }
        return null;
    }
    public void actualizarBill(int id, LocalDate dateTime, float total, Employee Employee, Customer Customer) {
        for (Bill bill : billList) {
            if (bill.getId() == id) {
                bill.setDateTime(dateTime);
                bill.setTotal(total);
                bill.setEmployee(Employee);
                bill.setCustomer(Customer);
                break;
            }
        }
    }
    public void eliminarBill(int id) {
        billList.removeIf(bill -> bill.getId() == id);
    }

    public List<Bill> listarBill() {
        return billList;
    }
}
