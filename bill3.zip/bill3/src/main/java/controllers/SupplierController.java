/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controllers;

import java.util.ArrayList;
import java.util.List;
import models.Supplier;

/**
 *
 * @author corne
 */
public class SupplierController {
    private List<Supplier> supplierList;

    public SupplierController() {
        this.supplierList = new ArrayList<>();
    }
    public void crearCustomer(int id, String name, String nameEnterprise, int numberPhone, String email) {
        Supplier supplier = new Supplier(id, name, nameEnterprise, numberPhone, email);
        supplierList.add(supplier);
    }

    public Supplier verSupplier(int id) {
        for (Supplier supplier : supplierList) {
            if (supplier.getId() == id) {
                return supplier;
            }
        }
        return null;
    }
    public void actualizarSupplier(int id, String name, String nameEnterprise, int numberPhone, String email) {
        for (Supplier supplier : supplierList) {
            if (supplier.getId() == id) {
                supplier.setName(name);
                supplier.setNameEnterprise(nameEnterprise);
                supplier.setNumberPhone(numberPhone);
                supplier.setEmail(email);
                break;
            }
        }
    }

    public void elimnarSupplier(int id) {
        supplierList.removeIf(supplier -> supplier.getId() == id);
    }

    public List<Supplier> listarSupplier() {
        return supplierList;
    }
}
