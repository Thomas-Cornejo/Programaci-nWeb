/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controllers;

import java.util.ArrayList;
import java.util.List;
import models.Branch;
import models.Company;

/**
 *
 * @author corne
 */
public class BranchController {
    private List<Branch> branchList;

    public BranchController() {
        this.branchList = new ArrayList<>();
    }
    public void crearBranch(int id, String name, String address, Company company) {
        Branch branch = new Branch(id, name, address, company);
        branchList.add(branch);
    }

    public Branch verBranch(int id) {
        for (Branch branch : branchList) {
            if (branch.getId() == id) {
                return branch;
            }
        }
        return null;
    }
    public void actualizarBranch(int id, String name, String address, Company company) {
        for (Branch branch : branchList) {
            if (branch.getId() == id) {
                branch.setName(name);
                branch.setAddress(address);
                branch.setCompany(company);
                break;
            }
        }
    }

    public void eliminarBranch(int id) {
        branchList.removeIf(branch -> branch.getId() == id);
    }

    public List<Branch> listarCustomers() {
        return branchList;
    }
}
